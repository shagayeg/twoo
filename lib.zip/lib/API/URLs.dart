const String host = "http://goftavard.ir";

// homePage
const String myurl = "/api/public/v1/store/home"; //GET